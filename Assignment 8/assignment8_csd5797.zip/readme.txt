Name: Chaitanya Dandane
UTA ID: 1001625797

Programming language: Python

Code structure:
1. Input arguments is given from command line which is observation string.
2. Prior probabilities logic is built into the code.
3. Posterior probablities are calculated by using prior probabilities by iterating through each observation sequence and store the result in result.txt file.
4. Probabilities are stored and calculated using an 2-D array.

Run the code with following command:
python compute_a_posteriori.py observation_sequence

NOTE:  observation_sequence should be specified in uppercase.